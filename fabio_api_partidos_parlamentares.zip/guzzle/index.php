<?php 
	requere 'vendor/autoload.php';

	$partidos = new GuzzLeHttp\partidos();
	$parlamentares = new GuzzLeHttp\parlamentares();
	//requisições: GET, POST, PUT, DELETE
	$resposta_partidos = $partidos->request('GET', 'https://dadosabertos.camara.leg.br/swagger/api.html#api');
	$resposta_parlamentares = $partidos->request('GET', 'https://dadosabertos.camara.leg.br/swagger/api.html#api');

	$resposta_partidos = $partidos->request('GET', 'https://dadosabertos.camara.leg.br/swagger/api.html#api');
	$resposta_parlamentares = $parlamentares->request('GET', 'https://dadosabertos.camara.leg.br/swagger/api.html#api');

	echo $resposta_partidos->getStatusCode();

	echo $resposta_parlamentares->getStatusCode();

 ?>