import React, { useEffect, useState } from "react"
import axios from "axios"

import * as S from "./App.styles"

import { Partido } from "types/Partido"
import { Parlamentar } from "types/Parlamentar"

const App = () => {
  const [partidos, setPartidos] = useState<Partido[]>([])
  const [parlamentares, setParlamentares] = useState<Parlamentar[]>([])
  
  const getPartidos = async () => {
    const response = await axios.get('https://dadosabertos.camara.leg.br/api/v2/partidos')
    setPartidos(response.data?.dados)
  }

  const getParlamentares = async (sigla: string) => {
    const response = await axios.get(`https://dadosabertos.camara.leg.br/api/v2/deputados?siglaPartido=${sigla}`)
    setParlamentares(response.data.dados)
  }

  const handleGetParlamentares = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const siglaDoPartido = e.target.value.split("-")[0]
    getParlamentares(siglaDoPartido)
  }

  useEffect(()=>{
    getPartidos()
  }, [])

  return (
    <S.Wrapper>
      <S.Heading>Aplicacao Dados Abertos</S.Heading>
      
      {partidos && (
        <select
          onChange={handleGetParlamentares}
          placeholder="Selecione um partido:"
        >
          {partidos.map(({ id, nome, sigla })=>{
            const fullName = `${sigla} - ${nome}`

            return (
              <>
                <option key={id}>
                  {fullName}
                </option>
                <br/>
              </>
            )
          })}
        </select>
      )}

      {partidos && parlamentares.length >= 1 && (
        <ul>
          {parlamentares.map(({ id, nome, siglaPartido, siglaUf, urlFoto })=>{
            const alternativeText = `Foto de ${nome}`

            return (
              <>
                <li key={id}>
                  Foto: <img src={urlFoto} alt={alternativeText} /><br/>
                  Nome: <strong>{nome}</strong><br/>
                  Sigla do Partido: <strong>{siglaPartido}</strong><br/>
                  UF: <strong>{siglaUf}</strong><br/>
                </li><br/>
              </>
            )
          })}
        </ul>
      )}

      {parlamentares.length === 0 && (
        <p>Nenhum parlamentar encontrado neste partido.</p>
      )}
    </S.Wrapper>
  )
}

export default App