export type Partido = {
  id: number,
  sigla: string,
  nome: 'string'
}