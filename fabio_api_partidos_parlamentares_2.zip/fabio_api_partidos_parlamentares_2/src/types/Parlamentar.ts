export type Parlamentar = {
  email: string | null
  id: number
  nome: string
  siglaPartido: string
  siglaUf: string
  urlFoto: string
}