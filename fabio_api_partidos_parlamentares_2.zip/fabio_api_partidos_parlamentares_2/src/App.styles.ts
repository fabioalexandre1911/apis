import styled from "styled-components"

export const Wrapper = styled.div`
  min-height: 100vh;
  background-color: aliceblue;

  img {
    max-width: 50px;
    max-height: 50px;
  }
`

export const Heading = styled.h1``